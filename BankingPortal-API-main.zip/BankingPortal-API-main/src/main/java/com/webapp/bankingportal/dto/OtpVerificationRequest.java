package com.webapp.bankingportal.dto;

public record OtpVerificationRequest(String identifier, String otp) {
}
