package com.webapp.bankingportal.dto;

public record ErrorResponse(String message) {
}
