package com.webapp.bankingportal.dto;

public record OtpRequest(String identifier) {
}
