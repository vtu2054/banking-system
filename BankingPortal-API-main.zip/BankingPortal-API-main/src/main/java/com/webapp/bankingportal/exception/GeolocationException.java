package com.webapp.bankingportal.exception;

public class GeolocationException extends RuntimeException {

    public GeolocationException(String message) {
        super(message);
    }
}
