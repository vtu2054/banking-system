package com.webapp.bankingportal.entity;

public enum TransactionType {
    CASH_WITHDRAWAL,
    CASH_DEPOSIT,
    CASH_TRANSFER,
    CASH_CREDIT
}
